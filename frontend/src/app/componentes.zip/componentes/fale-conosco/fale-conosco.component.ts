import { Component } from '@angular/core';

@Component({
  selector: 'app-fale-conosco',
  standalone: true,
  imports: [],
  templateUrl: './fale-conosco.component.html',
  styleUrl: './fale-conosco.component.css'
})
export class FaleConoscoComponent {

}
