import { Component } from '@angular/core';

@Component({
  selector: 'app-nossos-servicos',
  standalone: true,
  imports: [],
  templateUrl: './nossos-servicos.component.html',
  styleUrl: './nossos-servicos.component.css'
})
export class NossosServicosComponent {

}
