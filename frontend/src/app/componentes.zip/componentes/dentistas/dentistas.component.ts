import { Component } from '@angular/core';

@Component({
  selector: 'app-dentistas',
  standalone: true,
  imports: [],
  templateUrl: './dentistas.component.html',
  styleUrl: './dentistas.component.css'
})
export class DentistasComponent {

}
